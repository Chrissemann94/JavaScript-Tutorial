"use strict";

let jumbo = document.querySelector(".jumbotron");
// console.log(jumbo);

console.log(jumbo.innerHTML);
console.log(jumbo.innerText);
console.log(jumbo.textContent);