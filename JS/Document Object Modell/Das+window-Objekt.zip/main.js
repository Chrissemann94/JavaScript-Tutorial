"use strict";

console.log(window);

// Eigenschaften des window-Objekts
console.log(innerWidth);
console.log(innerHeight);
console.log(outerWidth);
console.log(outerHeight);
console.log(scrollX);
console.log(scrollY);
// für später im Kurs...
console.log(location);
console.log(localStorage);
console.log(sessionStorage);